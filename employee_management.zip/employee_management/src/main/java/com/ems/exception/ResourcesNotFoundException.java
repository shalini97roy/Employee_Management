package com.ems.exception;

public class ResourcesNotFoundException extends Exception{
	public ResourcesNotFoundException(String message)  {
		super(message);
		
		
	}
	

}
